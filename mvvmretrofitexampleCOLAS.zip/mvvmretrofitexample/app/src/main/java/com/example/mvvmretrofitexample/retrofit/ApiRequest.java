package com.example.mvvmretrofitexample.retrofit;

import retrofit2.http.GET;
import static com.example.mvvmretrofitexample.constant.AppConstant.API_KEY;
import com.example.mvvmretrofitexample.response.ArticleResponse;
import retrofit2.Call;

public interface ApiRequest {
    @GET("top-headlines?sources=techrunch&apiKey=" + API_KEY)
    Call<ArticleResponse> getTopHeadlines();
}
