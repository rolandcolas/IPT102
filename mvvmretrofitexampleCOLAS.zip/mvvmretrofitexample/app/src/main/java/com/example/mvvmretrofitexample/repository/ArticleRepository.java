package com.example.mvvmretrofitexample.repository;

public class ArticleRepository {
}
