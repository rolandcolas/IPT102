package com.example.mvvmretrofitexample.view_Model;

public class ArticleViewModel {

}
